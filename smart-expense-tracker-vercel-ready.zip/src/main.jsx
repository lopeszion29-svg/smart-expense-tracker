import React, { useEffect, useMemo, useState } from "react";
import { createRoot } from "react-dom/client";
import {
  Plus, Wallet, TrendingUp, TrendingDown, CalendarDays, ShoppingBag,
  Utensils, Car, Receipt, MoreHorizontal, Lightbulb, Target, Sparkles,
  X, Check, AlertTriangle, Trash2, ArrowRight, ShieldCheck, Smartphone,
  LogIn, UserRound, Download, LogOut
} from "lucide-react";
import { ResponsiveContainer, PieChart, Pie, Cell, Tooltip, BarChart, Bar, XAxis, YAxis, CartesianGrid } from "recharts";
import "./styles.css";

const EXPENSE_CATEGORIES=["Food & Drinks","Travel","Shopping","Utilities","Other"];
const STORAGE_KEY="smart-expense-transactions-v2";
const GOAL_KEY="smart-expense-goal-v2";
const SESSION_KEY="smart-expense-session-v2";
const money=n=>new Intl.NumberFormat("en-IN",{style:"currency",currency:"INR",maximumFractionDigits:0}).format(n||0);
const dateKey=d=>new Date(d).toISOString().slice(0,10);
const todayKey=dateKey(new Date());
const daysLeft=()=>{const n=new Date(),last=new Date(n.getFullYear(),n.getMonth()+1,0).getDate();return Math.max(1,last-n.getDate()+1)};
const passed=()=>new Date().getDate();

function App(){
  const [loggedIn,setLoggedIn]=useState(()=>localStorage.getItem(SESSION_KEY)==="1");
  const [authMode,setAuthMode]=useState("login");
  const [showLogin,setShowLogin]=useState(false);
  const [installPrompt,setInstallPrompt]=useState(null);

  useEffect(()=>{
    const handler=e=>{e.preventDefault();setInstallPrompt(e)};
    window.addEventListener("beforeinstallprompt",handler);
    if("serviceWorker" in navigator) navigator.serviceWorker.register("/sw.js").catch(()=>{});
    return()=>window.removeEventListener("beforeinstallprompt",handler);
  },[]);

  async function install(){
    if(!installPrompt)return;
    await installPrompt.prompt();
    setInstallPrompt(null);
  }
  function enterApp(){localStorage.setItem(SESSION_KEY,"1");setLoggedIn(true)}
  function logout(){localStorage.removeItem(SESSION_KEY);setLoggedIn(false)}

  if(!loggedIn) return <Landing showLogin={showLogin} setShowLogin={setShowLogin} authMode={authMode} setAuthMode={setAuthMode} enterApp={enterApp} install={install} canInstall={!!installPrompt}/>;
  return <Dashboard logout={logout} install={install} canInstall={!!installPrompt}/>;
}

function Landing({showLogin,setShowLogin,authMode,setAuthMode,enterApp,install,canInstall}){
 return <div className="landing">
   <nav className="landing-nav">
     <div className="brand"><div className="brand-icon"><Wallet/></div><div><b>Smart Expense</b><span>Simple money tracking</span></div></div>
     <div className="nav-actions">
       {canInstall&&<button className="ghost-btn" onClick={install}><Download size={17}/> Install</button>}
       <button className="login-link" onClick={()=>{setAuthMode("login");setShowLogin(true)}}>Log in</button>
       <button className="primary-btn small" onClick={()=>{setAuthMode("signup");setShowLogin(true)}}>Get started</button>
     </div>
   </nav>
   <main className="landing-main">
     <section className="landing-copy">
       <div className="pill"><Sparkles size={15}/> Smart, simple & private</div>
       <h1>Take control of your money, <span>one day at a time.</span></h1>
       <p>Track income, understand spending, plan purchases and build savings goals — without complicated financial jargon.</p>
       <div className="hero-actions">
         <button className="primary-btn hero-btn" onClick={()=>{setAuthMode("signup");setShowLogin(true)}}>Start tracking free <ArrowRight size={19}/></button>
         {canInstall&&<button className="outline-btn hero-btn" onClick={install}><Smartphone size={18}/> Install app</button>}
       </div>
       <div className="trust-row"><span><ShieldCheck size={17}/> Data stays on your device</span><span><Check size={17}/> No backend required</span></div>
     </section>
     <section className="preview-wrap">
       <div className="preview-glow"></div>
       <div className="preview-card">
         <div className="preview-top"><span>NET BALANCE</span><b>Smart Expense</b></div>
         <strong className="preview-balance">₹24,850</strong>
         <div className="preview-stats"><div><small>Income</small><b>₹35,000</b></div><div><small>Expenses</small><b>₹10,150</b></div></div>
         <div className="preview-limit"><div><span>Daily limit</span><b>₹830</b></div><div className="preview-track"><i/></div></div>
         <div className="preview-list"><div><i className="food"><Utensils/></i><span>Food & Drinks<small>Today</small></span><b>−₹240</b></div><div><i className="travel"><Car/></i><span>Travel<small>Yesterday</small></span><b>−₹120</b></div><div><i className="income-icon"><TrendingUp/></i><span>Income<small>Yesterday</small></span><b className="green">+₹2,000</b></div></div>
       </div>
     </section>
   </main>
   <section className="feature-row">
     <Feature icon={<TrendingUp/>} title="See clearly" text="Simple income, expense and balance summaries."/>
     <Feature icon={<Target/>} title="Reach goals" text="Track savings targets and estimated time."/>
     <Feature icon={<Sparkles/>} title="Smart tips" text="Friendly insights based on your spending."/>
   </section>
   <footer className="landing-footer">Smart Expense Tracker · Built for students, families and everyday life.</footer>
   {showLogin&&<AuthModal mode={authMode} setMode={setAuthMode} onClose={()=>setShowLogin(false)} enterApp={enterApp}/>}
 </div>
}
function Feature({icon,title,text}){return <div className="feature"><div>{icon}</div><h3>{title}</h3><p>{text}</p></div>}

function AuthModal({mode,setMode,onClose,enterApp}){
 const [email,setEmail]=useState("");const [password,setPassword]=useState("");const [error,setError]=useState("");
 function submit(e){e.preventDefault();if(!email.includes("@"))return setError("Please enter a valid email address.");if(password.length<4)return setError("Password should be at least 4 characters.");enterApp()}
 return <div className="modal-backdrop" onMouseDown={e=>e.target===e.currentTarget&&onClose()}>
   <div className="auth-modal">
    <button className="icon-btn close" onClick={onClose}><X/></button>
    <div className="auth-logo"><Wallet/></div><h2>{mode==="login"?"Welcome back":"Create your account"}</h2><p>{mode==="login"?"Log in to continue to your expense dashboard.":"Start managing your money with a simple local-first tracker."}</p>
    <div className="auth-tabs"><button className={mode==="login"?"active":""} onClick={()=>{setMode("login");setError("")}}>Log in</button><button className={mode==="signup"?"active":""} onClick={()=>{setMode("signup");setError("")}}>Sign up</button></div>
    <form className="form-stack" onSubmit={submit}><label>Email address<input type="email" value={email} onChange={e=>setEmail(e.target.value)} placeholder="Enter your email"/></label><label>Password<input type="password" value={password} onChange={e=>setPassword(e.target.value)} placeholder="Enter your password"/></label>{error&&<div className="error"><AlertTriangle size={16}/>{error}</div>}<button className="primary-btn full">{mode==="login"?<><LogIn size={18}/> Log in</>:<><UserRound size={18}/> Create account</>}</button></form>
    <button className="guest-btn" onClick={enterApp}>Continue without an account</button>
    <small className="auth-note">Demo authentication is local-only. No password is sent to a server.</small>
   </div>
 </div>
}

function Dashboard({logout,install,canInstall}){
 const [transactions,setTransactions]=useState(()=>{try{return JSON.parse(localStorage.getItem(STORAGE_KEY)||"[]")}catch{return[]}});
 const [goal,setGoal]=useState(()=>{try{return JSON.parse(localStorage.getItem(GOAL_KEY)||"null")}catch{return null}});
 const [modal,setModal]=useState(false),[simCost,setSimCost]=useState(""),[simTitle,setSimTitle]=useState(""),[goalTitle,setGoalTitle]=useState(""),[goalTarget,setGoalTarget]=useState(""),[notice,setNotice]=useState("");
 useEffect(()=>localStorage.setItem(STORAGE_KEY,JSON.stringify(transactions)),[transactions]);
 useEffect(()=>goal?localStorage.setItem(GOAL_KEY,JSON.stringify(goal)):localStorage.removeItem(GOAL_KEY),[goal]);
 const totals=useMemo(()=>{const income=transactions.filter(t=>t.type==="income").reduce((s,t)=>s+t.amount,0),expense=transactions.filter(t=>t.type==="expense").reduce((s,t)=>s+t.amount,0);return{income,expense,balance:income-expense}},[transactions]);
 const remaining=Math.max(0,totals.balance),limit=remaining/daysLeft();
 const categories=useMemo(()=>EXPENSE_CATEGORIES.map(name=>({name,value:transactions.filter(t=>t.type==="expense"&&t.category===name).reduce((s,t)=>s+t.amount,0)})).filter(x=>x.value>0),[transactions]);
 const last7=useMemo(()=>Array.from({length:7},(_,j)=>{const d=new Date();d.setDate(d.getDate()-(6-j));const k=dateKey(d);return{date:d.toLocaleDateString("en-IN",{weekday:"short"}),amount:transactions.filter(t=>t.type==="expense"&&dateKey(t.date)===k).reduce((s,t)=>s+t.amount,0)}}),[transactions]);
 const today=transactions.filter(t=>t.type==="expense"&&dateKey(t.date)===todayKey).reduce((s,t)=>s+t.amount,0);
 const food=categories.find(x=>x.name==="Food & Drinks")?.value||0,share=totals.expense?food/totals.expense:0;
 const avg=Math.max(0,totals.balance/passed()),saved=Math.max(0,totals.balance),progress=goal?Math.min(100,saved/goal.target*100):0,goalDays=goal&&avg>0?Math.ceil(Math.max(0,goal.target-saved)/avg):null;
 const advisor=transactions.length===0?["good","Your money space is ready","Add your first income or expense and I’ll start giving you simple spending tips."]:share>.4?["warn","Food is taking a big share","More than 40% of your spending is going to Food & Drinks. Try reducing eating out or planning meals."]:today>limit&&limit>0?["warn","Today is above your daily limit",`You’ve spent ${money(today)} today. Try slowing down on optional purchases for the rest of the day.`]:["good","You’re doing well","Your spending looks balanced. Keep checking your daily limit before making non-essential purchases."];
 function add(data){setTransactions(p=>[{...data,id:crypto.randomUUID()},...p]);setModal(false);flash("Transaction added successfully.")}
 function flash(t){setNotice(t);setTimeout(()=>setNotice(""),2500)}
 function saveGoal(e){e.preventDefault();const n=Number(goalTarget);if(!goalTitle.trim()||!Number.isFinite(n)||n<=0)return flash("Please enter a goal title and a target greater than zero.");setGoal({title:goalTitle.trim(),target:n});setGoalTitle("");setGoalTarget("");flash("Purchase goal saved.")}
 const sim=Number(simCost)||0,newLimit=Math.max(0,(remaining-sim)/daysLeft()),drop=Math.max(0,limit-newLimit);
 return <div className="app-shell">
  <header className="navbar"><div className="brand"><div className="brand-icon"><Wallet/></div><div><b>Smart Expense</b><span>Simple money tracking</span></div></div><div className="nav-actions">{canInstall&&<button className="ghost-btn" onClick={install}><Download size={17}/> Install</button>}<button className="ghost-btn logout" onClick={logout}><LogOut size={17}/> Log out</button><button className="primary-btn small" onClick={()=>setModal(true)}><Plus size={18}/> Add transaction</button></div></header>
  <main className="container">{notice&&<div className="toast"><Check size={18}/>{notice}</div>}
   <section className="hero-grid"><div className="balance-card"><div className="eyebrow">NET BALANCE</div><div className="balance">{money(totals.balance)}</div><p>{transactions.length?"Your current balance after recorded income and expenses.":"No transactions yet. Add your first transaction to get started."}</p><div className="balance-line"><span><CalendarDays size={16}/> This month</span><strong>{daysLeft()} days left</strong></div></div><div className="daily-card"><div className="daily-top"><span>Daily spending limit</span><div className="mini-icon"><CalendarDays size={19}/></div></div><strong>{money(limit)}</strong><p>Based on your remaining balance and days left this month.</p><div className="limit-track"><span style={{width:`${Math.min(100,limit?(today/limit)*100:0)}%`}}/></div><small>{money(today)} spent today</small></div></section>
   <section className="stats-grid"><Stat icon={<TrendingUp/>} label="Total Income" value={totals.income} tone="green"/><Stat icon={<TrendingDown/>} label="Total Expense" value={totals.expense} tone="red"/><Stat icon={<Wallet/>} label="Net Balance" value={totals.balance} tone="blue"/></section>
   <section className="section-head"><div><h2>Spending overview</h2><p>See where your money is going at a glance.</p></div></section>
   <section className="charts-grid"><Card title="Expenses by category" icon={<Receipt/>}>{categories.length?<div className="donut-wrap"><ResponsiveContainer width="100%" height={250}><PieChart><Pie data={categories} dataKey="value" nameKey="name" innerRadius={68} outerRadius={94} paddingAngle={3}>{categories.map((_,i)=><Cell key={i} fill={["#0284c7","#38bdf8","#0ea5e9","#0369a1","#7dd3fc"][i%5]}/>)}</Pie><Tooltip formatter={v=>money(v)}/></PieChart></ResponsiveContainer><div className="legend">{categories.map((x,i)=><div key={x.name}><span className="dot" style={{background:["#0284c7","#38bdf8","#0ea5e9","#0369a1","#7dd3fc"][i%5]}}/>{x.name}<b>{money(x.value)}</b></div>)}</div></div>:<EmptyState text="No transactions yet" sub="Your category chart will appear after you add an expense."/>}</Card><Card title="Daily spending · last 7 days" icon={<TrendingDown/>}>{transactions.some(t=>t.type==="expense")?<ResponsiveContainer width="100%" height={310}><BarChart data={last7} margin={{top:10,right:5,left:0,bottom:5}}><CartesianGrid strokeDasharray="3 3" stroke="#e0f2fe"/><XAxis dataKey="date" tick={{fill:"#475569",fontSize:12}}/><YAxis tick={{fill:"#475569",fontSize:12}}/><Tooltip formatter={v=>money(v)}/><Bar dataKey="amount" fill="#0284c7" radius={[7,7,0,0]}/></BarChart></ResponsiveContainer>:<EmptyState text="No transactions yet" sub="Your 7-day spending chart will appear here."/>}</Card></section>
   <section className="smart-grid"><Card title="What-If Purchase Simulator" icon={<ShoppingBag/>} subtitle="Check a purchase before you buy it."><div className="form-stack"><label>Planned item title<input value={simTitle} onChange={e=>setSimTitle(e.target.value)} placeholder="Enter item title"/></label><label>Planned cost<input type="number" min="0" value={simCost} onChange={e=>setSimCost(e.target.value)} placeholder="Enter amount"/></label></div>{sim>0?<div className="impact-box"><div><span>New daily limit</span><strong>{money(newLimit)}</strong></div><div><span>Daily limit drop</span><strong className="red-text">{money(drop)}</strong></div></div>:<div className="soft-note"><Lightbulb size={18}/> Enter a planned cost to see its impact.</div>}</Card><Card title="Purchase Goal Tracker" icon={<Target/>} subtitle="Save toward something important.">{goal?<div className="goal-view"><div className="goal-row"><div><b>{goal.title}</b><span>Target: {money(goal.target)}</span></div><button className="icon-btn" onClick={()=>setGoal(null)}><Trash2 size={18}/></button></div><div className="progress"><span style={{width:`${progress}%`}}/></div><div className="goal-meta"><b>{money(saved)} saved</b><span>{Math.round(progress)}%</span></div><p className="muted">{goalDays===null?"Add income and expenses to estimate your saving time.":goalDays===0?"Goal reached! 🎉":`Estimated ${goalDays} days to reach your goal at your current saving rate.`}</p></div>:<form onSubmit={saveGoal} className="form-stack"><label>Goal title<input value={goalTitle} onChange={e=>setGoalTitle(e.target.value)} placeholder="Enter goal target title"/></label><label>Target amount<input type="number" min="0" value={goalTarget} onChange={e=>setGoalTarget(e.target.value)} placeholder="Enter amount"/></label><button className="secondary-btn"><Target size={18}/> Set goal</button></form>}</Card></section>
   <section className={`advisor ${advisor[0]}`}><div className="advisor-icon"><Sparkles size={22}/></div><div><div className="advisor-label">SMART ADVISOR</div><h3>{advisor[1]}</h3><p>{advisor[2]}</p></div></section>
   <section className="section-head transactions-head"><div><h2>Recent transactions</h2><p>Your latest money activity.</p></div></section><section className="card transactions">{transactions.length?transactions.slice(0,8).map(t=><div className="transaction" key={t.id}><div className={`transaction-icon ${t.type}`}><TransactionIcon category={t.category}/></div><div className="transaction-main"><b>{t.title}</b><span>{t.category} · {new Date(t.date).toLocaleDateString("en-IN")}</span></div><strong className={t.type==="income"?"income-text":"red-text"}>{t.type==="income"?"+":"-"}{money(t.amount)}</strong><button className="delete-btn" onClick={()=>setTransactions(p=>p.filter(x=>x.id!==t.id))}><Trash2 size={17}/></button></div>):<EmptyState text="No transactions yet" sub="Your recent income and expenses will appear here."/>}</section>
   <footer>Smart Expense Tracker · Your data stays in your browser using LocalStorage.</footer>
  </main>{modal&&<TransactionModal onClose={()=>setModal(false)} onSave={add}/>}</div>
}
function Stat({icon,label,value,tone}){return <div className="stat card"><div className={`stat-icon ${tone}`}>{icon}</div><div><span>{label}</span><strong>{money(value)}</strong></div></div>}
function Card({title,subtitle,icon,children}){return <div className="card panel"><div className="panel-head"><div className="panel-title"><div className="panel-icon">{icon}</div><div><h3>{title}</h3>{subtitle&&<p>{subtitle}</p>}</div></div></div>{children}</div>}
function EmptyState({text,sub}){return <div className="empty"><div className="empty-icon"><MoreHorizontal/></div><b>{text}</b><span>{sub}</span></div>}
function TransactionIcon({category}){if(category==="Food & Drinks")return <Utensils size={20}/>;if(category==="Travel")return <Car size={20}/>;if(category==="Shopping")return <ShoppingBag size={20}/>;return <Receipt size={20}/>}
function TransactionModal({onClose,onSave}){const[type,setType]=useState("expense"),[title,setTitle]=useState(""),[amount,setAmount]=useState(""),[category,setCategory]=useState(EXPENSE_CATEGORIES[0]),[date,setDate]=useState(todayKey),[error,setError]=useState("");function submit(e){e.preventDefault();const n=Number(amount);if(!title.trim())return setError("Please enter a title.");if(!Number.isFinite(n)||n<=0)return setError("Amount must be greater than zero.");onSave({title:title.trim(),amount:n,type,category:type==="income"?"Income":category,date})}return <div className="modal-backdrop" onMouseDown={e=>e.target===e.currentTarget&&onClose()}><div className="modal"><div className="modal-head"><div><h2>Add transaction</h2><p>Record money coming in or going out.</p></div><button className="icon-btn" onClick={onClose}><X/></button></div><div className="tabs"><button className={type==="income"?"active":""} onClick={()=>setType("income")}>Income</button><button className={type==="expense"?"active":""} onClick={()=>setType("expense")}>Expense</button></div><form onSubmit={submit} className="form-stack"><label>Title<input autoFocus value={title} onChange={e=>setTitle(e.target.value)} placeholder="Enter item title"/></label><label>Amount<input type="number" min="0" step="0.01" value={amount} onChange={e=>setAmount(e.target.value)} placeholder="Enter amount"/></label>{type==="expense"?<label>Category<select value={category} onChange={e=>setCategory(e.target.value)}>{EXPENSE_CATEGORIES.map(c=><option key={c}>{c}</option>)}</select></label>:<div className="disabled-field"><span>Category</span><b>Income</b></div>}<label>Date<input type="date" value={date} onChange={e=>setDate(e.target.value)}/></label>{error&&<div className="error"><AlertTriangle size={17}/>{error}</div>}<button className="primary-btn full"><Check size={18}/> Save transaction</button></form></div></div>}
createRoot(document.getElementById("root")).render(<App/>);
