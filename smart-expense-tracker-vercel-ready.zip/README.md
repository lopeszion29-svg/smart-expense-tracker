# Smart Expense Tracker — Vercel Ready

## Features
- Polished responsive landing page
- Local demo login/sign-up screen
- Guest/quick entry
- Responsive expense dashboard
- LocalStorage transactions and goals
- Recharts analytics
- What-If purchase simulator
- Purchase goal tracker
- Rule-based Smart Advisor
- PWA manifest + service worker
- Install-app support where the browser supports it
- Vercel SPA rewrite configuration

## Run locally

```bash
npm install
npm run dev
```

## Build

```bash
npm run build
```

Vite outputs the production app to `dist/`.

## Deploy to Vercel

1. Upload this project to GitHub.
2. Import the repository into Vercel.
3. Framework preset: **Vite**.
4. Build command: `npm run build`.
5. Output directory: `dist`.
6. Deploy.

The included `vercel.json` handles SPA routes.

### Important
The login is a front-end demo flow. There is no real account server and no password is uploaded anywhere. Transaction and goal data remain in the browser's LocalStorage.
